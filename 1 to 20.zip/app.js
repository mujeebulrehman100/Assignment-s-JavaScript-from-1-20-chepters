// Chapter# 1 : Alert

 //Q#1 
//alert("Welcome to my website")

// // Q#2 
//alert("Error! Please enter a valid password.")

// // Q#3
// alert("Welcome to JS land...\nHappy Coding!")

// Q#4

 //alert("Welcome to JS Land...")
//alert("Happy Coding!")



// Q#5
//alert("Hello... I can run JS through my web browser's console");

// Q#6
// Practical, we can palce script file in html any where 


// Chapter# 2:  VARIABLES FOR STRINGS

// Q#1
// var username;


// Q#2
// var userName = "MUJEEB UL REHMAN";
// alert("userName");
//var myName = "Mujeeb Rehman"
//alert(myName)


// Q#3
// a) 
// var message;
// // b)
// message = "“Hello World”"
// // c)
// alert(message)


// // Q#4
//var userName = "mujeeb ul Rehman";
// var age = 19;
// var course = "Modern web application and development"

//alert(userName)
//alert("Age ==> " + age)
//  alert("Course ==> " +course)


/*var userName = "REHMAN"
var age = 18;
var course = " Mobile Web development"
alert(" My name " + userName)
alert( "My age is " + age)
alert("My course is" + course)*/
// // Q#5
// alert("PIZZA\nPIZZ\nPIZ\nPI\nP")

// // Q#6
/*var email="rehmanleghari786@gmail.com"
 alert("My email address is " + email)*/


// Q#7
// var book = "“A smarter way to learn JavaScript”"
// alert("I am trying to learn from the Book " + book)


// Q#8 
//document.write("Yah! I can write HTML content through JavaScript")
//document.write("Wah! I can //write html content through //javascript");

// // Q#9
//var str = "▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬"
 //alert(str)




// Chapter# 3: VARIABLES FOR NUMBERS

// Q#1
// var age = 19;
// alert(age)

// // Q#2
// var times = 11;
// alert("You have visited this site" + times + "times")

// // Q#3
// var birthYear = 2006;
// document.write("My birth year is " + birthYear)
// alert("Data type of my ddeclare variable is " + typeof (birthYear))



// // Q#4
// var visitorName = "Asad";
// var productTitle = "T-shorts";
// var Quantity = 7;
// document.write(visitorName + " Ordered " + Quantity + productTitle + "on daraz")


// Chapter# 4 VARIABLE NAMES: LEGAL & ILLEGAL


// Q#1
// var x = 10, y = 20, z = 30;


// Or use array destructuring (ES6+):
// var [x, y, z] = [2, 3, 4];




// Q#2
// legal
// var _name = "ali";     // ✅ starts with _
// var my2age = 22;       // ✅ letters followed by number
// var num_2 = 2;         // ✅ letters and underscore
// var $name = "khan";    // ✅ $ is allowed
// var myName = "khan";   // ✅ standard camelCase


// var myName = "Atta ul Rehman";
// var age123 = 25;
// var _score = 100;
// var $salary = 5000;
// var user1 = "Ali";


// Illegal
// var my age = 22
// var age-my = 22
// var 2meer = "khan" 
// var #name = "ali"
// var for = 99



// var 1name = "Ali";       // starts with a number ❌
//var my-name = "Atta ul Rehman";   // hyphen not allowed ❌
// var var = 10;            // reserved keyword ❌
// var @money = 100;        // special character ❌
// var first name = "Ali";  // space not allowed ❌

// Q#3
// document.write("<b>“Rules for naming JS variables”</b> <br>")

// document.write("Variable names can only contain <strong>letters, numbers, $, and _</strong>.<br>For example: <strong>$my_1stVariable</strong> <br>")
// document.write("Variables must begin with a <strong>letter, $ or _</strong>.<br>For example: <strong>$name, _name, or name</strong> <br>")
// document.write("Variable names are case <strong>sensitive</strong> <br>")

// document.write("Variable names should not be JS <strong>keywords</strong>. <br>")




// Chapter#5: MATH EXPRESSIONS
// Q#1
// var num1 = +prompt(("Enter num1: "))
// var num2 = +prompt(("Enter num2: "))
// var result = num1 + num2
// document.write("Sum of " +num1 +  " and " + num2 + " is " + result + "<br>")

// // Q#2
// var result1 = num1 - num2
// document.write("Subtraction of " +num1 +  " and " + num2 + " is " + result1 + "<br>")


// var result2 = num1 / num2
// document.write("division of " +num1 +  " and " + num2 + " is " + result2 + "<br>")


// var result3 = num1 * num2
// document.write("Subrtraction of " +num1 +  " and " + num2 + " is " + result3 + "<br>")


// var result4 = num1 % num2
// document.write("Modules of " +num1 +  " and " + num2 + " is " + result4 + "<br>")


// Q#3
// var num;
// document.write("Value after variable declaration is:" + num + "<br>")

// c
// num = 4;
// document.write("Initial value: " + num + ". <br>")

// // e 
// ++num
// document.write("Value after increment is:" + num + '. <br>')

// // g 
// num += 7
// document.write("Value after addition is:" + num + '. <br>')


// // i 
// --num
// document.write("Value after decrement is:" + num + '. <br>')

// var result = num % 5
// document.write("Output : “The remainder is : " + result + '. <br>')


// Q#4
// var oneTicketPrice = 600
// var tickets = 5
// document.write("Total cost to buy " + tickets + " tickets to a movie is " + tickets * oneTicketPrice + "PKR <br>")



// Q#5
// var table = 5;
// document.write("Table of " + table + "<br>")
// document.write(table + " X 1 = " + table * 1 + "<br>")
// document.write(table + " X 2 = " + table * 2 + "<br>")
// document.write(table + " X 3 = " + table * 3 + "<br>")
// document.write(table + " X 4 = " + table * 4 + "<br>")
// document.write(table + " X 5 = " + table * 5 + "<br>")
// document.write(table + " X 6 = " + table * 6 + "<br>")
// document.write(table + " X 7 = " + table * 7 + "<br>")
// document.write(table + " X 8 = " + table * 8 + "<br>")
// document.write(table + " X 9 = " + table * 9 + "<br>")
// document.write(table + " X 10 = " + table * 10 + "<br>")



// Q#6
// var celsius = 25;
// var fahrenheit_convert = ((celsius * 9/5) + 32)
// document.write(celsius + "ºC is " +fahrenheit_convert + "ºF <br>")

// fahrenheit = 70;
// var celsiusConvert = ((fahrenheit - 32) * 5/9)
// document.write(fahrenheit + "ºF is " +celsiusConvert + "ºC <br>")



// Q#7
// a)
// var priceOfItem1 = 650;
// var priceOfItem2 = 100;
// var quantityOfItem1 = 3;
// var quantityOfItem2 = 7;
// var shipingCharges = 100;
// var result = (priceOfItem1 * quantityOfItem1) + (priceOfItem2 * quantityOfItem2) + shipingCharges

// document.write("<h2>Shopping Cart</h2> <br>")
// document.write("Price of item 1 is " + priceOfItem1 + "<br>")
// document.write("Quantity of item 1 is " + quantityOfItem1 + "<br>")

// document.write("Price of item 2 is " + priceOfItem2 + "<br>")
// document.write("Quantity of item 2 is " + quantityOfItem2 + "<br>")

// document.write("Shopping Charges " + shipingCharges + "<br> <br>")

// document.write("Total cost of your order is  " + result + "<br>")



// Q#8
// var totalMarks = 1100;
// var obtainMarks = 777;
// var percentage = obtainMarks / totalMarks * 100
// document.write("<h2> Marks Sheet </h2> <br>")
// document.write(" Total marks: " + totalMarks + "<br>")
// document.write(" Obtained marks: " + obtainMarks +"<br>")
// document.write(" Percentage: " + percentage + "<br>")


// Q#9
// var usDollar1 = 104.80
// var saudiRiyal1 = 28
// var pakistaniCurrency = 10 * usDollar1
// var pakistaniCurrency1 = 25 * saudiRiyal1
// var totalCurrency = pakistaniCurrency + pakistaniCurrency1
// document.write("Total Currency in PKR: " +totalCurrency)
// Or 
// var totalCurrency = (10 * 104.80) + (25 * 28);
// alert(totalCurrency);
// Or 
// var usDollar1 = 104.80;
// var saudiRiyal1 = 28;

// var totalCurrency = (10 * usDollar1) + (25 * saudiRiyal1);
// alert(totalCurrency);

// Q#10
// var num = 7
// var calculation = ((num + 5) * 10) / 2;
// alert(calculation) 

// Q#11
// var currentYear = 2025;
// var birthYear = 2006;

// var age1 = currentYear - birthYear;
// var age2 = age1 - 1;                      

// document.write("<h2>Age Calculator</h2> <br>")
// document.write("Current Year: " + currentYear + "<br>")
// document.write("Birth Year: " + birthYear + "<br>")
// document.write("They are either " + age2 + " or " + age1 + " years old <br>");


// Q#12
// var radius = 20;               // Store radius
// var pi = 3.142;               // Value of π

// document.write("Radius of a circle: " + radius)
// var circumference = 2 * pi * radius;
// document.write("The circumference is " + circumference + "<br>");


// var area = pi * radius * radius;  // or pi * Math.pow(radius, 2)
// document.write("The area is " + area);


// Q#13
// A 
// var favouriteSnack = "chocolate chip";
// var currentAge = 15;
// var maxAge = 65;
// var amountSnack = 3;

// var yearsRemaining = maxAge - currentAge;
// var totalNeeded = yearsRemaining * 365 * amountSnack;  // Use amountSnack, not amountPerDay

// document.write("<h2>Lifetime Supply Calculator</h2>");
// document.write("Favorite Snack: " + favouriteSnack + "<br>");
// document.write("Current Age: " + currentAge + "<br>");
// document.write("Estimated Maximum Age: " + maxAge + "<br>");
// document.write("Amount Per Day: " + amountSnack + "<br><br>");
// document.write("You will need " + totalNeeded + " " + favouriteSnack + " to last you until the ripe old age of " + maxAge + ". <br>");


//Chapter # 6: MATH EXPRESSIONS

// Q#1
// var a = 10;
// document.write("<h2>Result :</h2> <br>")
// document.write("The value of a is: " + a + "<br>")
// document.write("----------------------------------- <br>")

// ++a
// document.write("The value of ++a is: " + a + "<br>")
// document.write("Now the value of a is: " + a + "<br>")


// document.write("The value of a++ is: " + a + "<br>")
// a++
// document.write("Now the value of a is: " + a + "<br>")

// --a
// document.write("The value of --a is: " + a + "<br>")
// document.write("Now the value of a is: " + a + "<br>")

// document.write("The value of a-- is: " + a + "<br>")
// a--
// document.write("Now the value of a is: " + a + "<br>")


// Q#2
// var a = 2;
// var b = 1;
// document.write("The value of b is " + b + "<br>")
// document.write("The value of a is " + a + "<br>")
// var result = --a - --b + ++b + b--;
// document.write("The value of  --a - --b + ++b + b-- is ==> " + result + "<br>")

// Q#3
// var userInput = prompt("Enter your name:  ")
// alert("Welcome, " + userInput)


// Q#4
// var table = +prompt("Enter a number: ", 5)
// document.write("The table of " + table + "<br>")
// document.write(table + " x 1 = " + table * 1 + "<br>")
// document.write(table + " x 2 = " + table * 2 + "<br>")
// document.write(table + " x 3 = " + table * 3 + "<br>")
// document.write(table + " x 4 = " + table * 4 + "<br>")
// document.write(table + " x 5 = " + table * 5 + "<br>")
// document.write(table + " x 6 = " + table * 6 + "<br>")
// document.write(table + " x 7 = " + table * 7 + "<br>")
// document.write(table + " x 8 = " + table * 8 + "<br>")
// document.write(table + " x 9 = " + table * 9 + "<br>")
// document.write(table + " x 10 = " + table * 10 + "<br>")


// Q#5
// a) Three subjects
// var sub1 = prompt("Enter the subject 1: ");
// var sub2 = prompt("Enter the subject 2: ");
// var sub3 = prompt("Enter the subject 3: ");

// // b) Total per subject
// var totalPerSub = 100;

// // Marks
// var mark1 = +prompt("Enter the subject 1 marks: ");
// var mark2 = +prompt("Enter the subject 2 marks: ");
// var mark3 = +prompt("Enter the subject 3 marks: ");

// // Individual percentages
// var perc1 = (mark1 / totalPerSub) * 100;
// var perc2 = (mark2 / totalPerSub) * 100;
// var perc3 = (mark3 / totalPerSub) * 100;

// // Totals
// var totalMarks = totalPerSub * 3;
// var obtainedMarks = mark1 + mark2 + mark3;
// var overallPerc = (obtainedMarks / totalMarks) * 100;

// // Output
// document.write("<h2>Subject Total Marks Obtained Marks Percentage</h2>");
// document.write("<table border='1' cellspacing='0' cellpadding='5'>");
// document.write("<tr><th>Subject</th><th>Total Marks</th><th>Obtained Marks</th><th>Percentage</th></tr>");

// document.write("<tr><td>" + sub1 + "</td><td>100</td><td>" + mark1 + "</td><td>" + Math.round(perc1) + "%</td></tr>");
// document.write("<tr><td>" + sub2 + "</td><td>100</td><td>" + mark2 + "</td><td>" + Math.round(perc2) + "%</td></tr>");
// document.write("<tr><td>" + sub3 + "</td><td>100</td><td>" + mark3 + "</td><td>" + Math.round(perc3) + "%</td></tr>");

// document.write("<tr><th>Total</th><th>" + totalMarks + "</th><th>" + obtainedMarks + "</th><th>" + Math.round(overallPerc) + "%</th></tr>");
// document.write("</table>");


// Chapter# 7 USER INPUT & CONDITIONAL STATEMENT
// Q#1 
// var cityName = prompt("Enter a city name: ").toLowerCase()
// if (cityName === "karachi"){
//     alert("Welcome to city of lights")
// }

// var gender = prompt("Enter your gender: ").toLowerCase()
// if(gender === "male") {
//     alert("Good morning Sir")
// } else if (gender === "female"){
//     alert("Good Morning Ma'am")
// } else("Enter the correct gender(male or female)")

// var signalColors = prompt("Enter the signal color name: ").toLowerCase()
// if(signalColors === "red"){
//     alert("Must Stop")
// } else if(signalColors === "yellow"){
//     alert("Ready to move")
// } else if(signalColors === "green"){
//     alert("Move now")
// } else{
//     alert("Enter the correct color(red, yellow, and green")
// }

// // Q#4
// var remainigFuel = +prompt("Enter the remainingfuel: ")
// if(remainigFuel === 0.25 ){
//     alert("Please refill the fuel in your car")
// }


// Q#5
// var sub1 = +prompt("Enter the marks of subject 1");
// var sub2 = +prompt("Enter the marks of subject 2");
// var sub3 = +prompt("Enter the marks of subject 3");
// var totalMarks = +prompt("Enter the total marks: ")
// var obtainedMarks = sub1 + sub2 + sub3;
// var percentage = (obtainedMarks / totalMarks) * 100;
// var grade;
// var remarks;
// if(percentage >= 80){
//     grade = "A-one";
//     remarks = "Excellent"
// } else if (percentage >= 70){
//     grade = "A"
//     remarks = "Good"
// } else if (percentage >= 60){
//     grade = "B"
//     remarks = "You need to improve"
// } else if (percentage < 60){
//     grade = "fail"
//     remarks = "Sorry"
// }

// document.write("<h2>Marks Sheet</h2>" + "<br>")
// document.write("Total marks :", totalMarks + "<br>")
// document.write("Marks obtained :", obtainedMarks + "<br>")
// document.write("Percentage :", percentage + "<br>")
// document.write("Grade:", grade + "<br>")
// document.write("Remarks :", remarks + "<br>")


// Q#7
// var secretNum = 7;
// var userNum = +prompt("Enter a number (1–10): ")
// if(userNum === secretNum){
//     alert("Bingo! Correct answer.")
// } else if(userNum + 1 === secretNum || userNum - 1 === secretNum){
//     alert("Close enough to the correct answer.")
// }  else {
//     alert("Sorry, try again!");
// }

// Q#8
// var numberCheck = +prompt("Enter a number: ")
// // if(numberCheck % 2 === 0){
// if(numberCheck % 2 !== 1){
//     alert("The Number " + numberCheck + " is even!" )
// } else{
//     alert("The number " + numberCheck + " is odd!")
// }

// Q#10
// var temp = +prompt("Enter the temperature to know about weather: ")
// if(temp > 40){
//     alert("It is too hot outside")
// } else if(temp > 30){
//     alert("The Weather today is Normal")
// } else if(temp > 20){
//     alert("Today's Weather is cool.")
// } else if(temp > 10){
//     alert("OMG! Toady's weather is so Cool.")
// } else{
//     alert("It is out of range of cooling..")
// }


// Q#11
// var userNum1 = +prompt("Enter the first num: ")
// var userNum2 = +prompt("Enter the second num: ")
// var selectOperation = prompt("Select operation (-, +, * , /, %)")
// var result;

// if(selectOperation === "+"){
//     result = userNum1 + userNum2
// } else if(selectOperation === "-"){
//     result = userNum1 - userNum2
// } else if (selectOperation === "*"){
//     result = userNum1 * userNum2
// } else if (selectOperation === "/"){
//     if(userNum2 === 0){
//         alert("Cannot divide by zero!");
//         } else{
//         result = userNum1 / userNum2
//     }
// }  else if (selectOperation === "%"){
//     if(userNum2 === 0){
//         alert("Cannot take modulus with zero!")
//     } else{
//         result = userNum1 % userNum2;
//     } 
// } else{
//     alert("Invalid operation selected!")
// }
// if(result !== undefined){
//     alert("Result is: "+ result)
// }


// Chapter # 8
// IF...ELSE & ELSE IF STATEMENT,
// TESTING SET OF CONDITIONS

// Q#1
// var character = prompt("Enter a character: ")
// var ascii = character.charCodeAt(0);

// if (ascii >= 48 && ascii <= 57){
//     alert("You entered a Number.")
// } else if (ascii >= 65 && ascii <= 90){
//     alert("You entered an uppercase letter.")
// } else if (ascii >= 97 && ascii <= 122) {
//       alert("You entered a Lowercase Letter");
// } else {
//       alert("This is neither a number nor an English letter.");
// }
/*
Explanation

charCodeAt(0) → gives ASCII value of first character.

Numbers: 48–57 (0–9)

Uppercase letters: 65–90 (A–Z)

Lowercase letters: 97–122 (a–z)
 */


// Q#2
// var num1 = +prompt("Enter first integer:");
// var num2 = +prompt("Enter second integer:");

// if(num1 > num2){
//     alert("The larger number is: " + num1 )
// } else if(num2 > num1){
//     length("The larger number is: " + num2)
// } else {
//     alert("Both numbers are equal: " + num1)
// }

// Q#3
// var numberChecking = +prompt("Enter a number: ") 
// if(numberChecking > 0){
//     alert("The number "+ numberChecking +" is postive")
// } else if(numberChecking < 0){
//     alert("The number "+ numberChecking +" is negative ")
// } else{
//     alert("The number is zero")
// }

// Q#4
// var character = prompt("Enter a character: ").toLowerCase()
// // var vowels = ["a", "e", "i", "o", "u"];

// // if (vowels.includes(character)) { 
// // or 
// // if("aeiou".includes(character)){
// // or 
// if(character === "a" || character === "e" || character === "i" || character === "o" || character === "u"){
//     alert(true)
// } else{
//     alert(false)
// }


// Q#5
// var password = "admin";
// var userPassword = prompt("Enter password: ")
// if(!userPassword){
//     alert("Please enter your password")
// } else  if(userPassword === password){
//     alert("Correct! The password you entered matches the original password");
// } else {
//     alert("Incorrect password")
// }

// Q#6
// var greeting;
// var hour = 13;
// if(hour < 18){
//     greeting = "Good day"
// } else {
//     greeting("Good evening")
// }
// alert(greeting)

// or 
// var hour = 13;
// var greeting = hour < 18 ? "Good day" : "Good evening";
// console.log(greeting);


// chapters9-11.pdf
// Conditions 
// Q#1
var userInput = prompt("Enter the city name:").toLowerCase();

if (userInput === "karachi") {
    alert("Welcome to city of lights");
}
//  else if (userInput === "lahore") {
//     alert("Welcome to the heart of Pakistan");
// } else {
//     alert("City not recognized");
// }


// Q#2 
userInput = prompt("Enter your gender(greeting): ").toLocaleLowerCase()
if (userInput === "male"){
    alert("Good morning Sir.")
} else if (userInput === "female"){
    alert("Good Morning ma'am")
}



// Q#30.24
userInput = prompt("Enter a color to know traffic: ")
if (userInput === "red"){
    alert("Must Stop")
} else if (userInput === "yellow"){
    alert("Ready to move")
} else if (userInput === "green"){
    alert("Move now")
}


// Q#4
remain_fuel = parseFloat(prompt("Enter remaining fuel in car: "))
if (remain_fuel < 0.24){
    alert("Please refill the fuel in your car")
}

// Q#5 



// Q#6
totalMarks = +prompt("Enter the total marks: ")
sub1 = +prompt("Enter your first subject marks")
sub2 = +prompt("Enter your second subject marks")
sub3 = +prompt("Enter your third subject marks")

// Add all three subject marks
var obtainMarks = sub1 + sub2 + sub3

// Calculate percentage
var percentage = (obtainMarks / totalMarks) * 100;


// Check grade and remarks
var grade, remarks;
if (percentage >= 80){
    grade  = "A-one"
    remarks = "excellent"
} else if (percentage >= 70){
    grade  = "A"
    remarks = "good"
} else if (percentage >= 60){
    grade  = "B"
    remarks = "You need to improve"
} else {
    grade  = "Fail"
    remarks = "Sorry"
}

// Start writing to document
document.write("<h1>Marks Sheet</h1>");
document.write("Total Marks: " + totalMarks + "<br>");
document.write("Marks Obtained: " + obtainMarks + "<br>");
document.write("Percentage: " + percentage.toFixed(2) + "%<br>");
document.write("Grade: " + grade + "<br>");
document.write("Remarks: " + remarks + "<br>");300


// Q#7
secret_number = (Math.floor(Math.random() * 10) + 1)

user_prompt = +prompt("Enter a number between 1 and 10:")
if (user_prompt === secret_number){
    alert("🎉 Bingo! Correct anwser")    
} else if(user_prompt === secret_number + 1 || user_prompt === secret_number - 1){
    alert("✨ Close enough to the correct answer")
} else {
    alert("❌ Wrong guess. Try again!");
}

// Q#8
var user_input = +prompt("Enter a number:");

if (user_input % 3 === 0) {
    alert("The number " + user_input + " is divisible by 3.");
} else {
    alert("The number " + user_input + " is NOT divisible by 3.");
}

// Q#9
var user_input = +prompt("Enter a number:");
if (user_input % 2 === 0){
    alert("The number  "+ user_input+" is even!")
} else{
    alert("The number "+ user_input +" is odd")
}




// Q#10
var temp = +prompt("Enter the temoerature: ")
if (temp > 40) {
    alert("It is too hot outside.")
} else if (temp > 30){
    alert("The weather today is Normal")
} else if (temp > 20){
    alert("Today's Weather is cool.")
} else if(temp > 10){
    alert("OMG! Today's weather i so Cool.")
} else {
    alert("It's freezing! Stay warm.");
}



// Q#11
// Calculator 
// Q#11 - Simple Calculator

var num1 = +prompt("Enter first number:");
var num2 = +prompt("Enter second number:");
var operation = prompt("Select your operation: (+, -, *, /, %)");

var result;

if (operation === "+") {
    result = num1 + num2;
    alert("Result: " + result);
} 
else if (operation === "-") {
    result = num1 - num2;
    alert("Result: " + result);
} 
else if (operation === "*") {
    result = num1 * num2;
    alert("Result: " + result);
} 
else if (operation === "/") {
    if (num2 === 0) {
        alert("Error: Cannot divide by zero!");
    } else {
        result = num1 / num2;
        alert("Result: " + result);
    }
} 
else if (operation === "%") {
    if (num2 === 0) {
        alert("Error: Cannot divide by zero!");
    } else {
        result = num1 % num2;
        alert("Result: " + result);
    }
} 
else {
    alert("Error: Please enter a valid operation (+, -, *, /, %)");
}


// chapters12-13
// If..else and else if statement, testing set of condition

var input = prompt("Enter a single character:");

if (input.length !== 1) {
       console.log("Please enter exactly one character.");
} else {
  var charCode = input.charCodeAt(0);

  if (charCode >= 48 && charCode <= 57) {
           console.log
("You entered a Number.");
  } else if (charCode >= 65 && charCode <= 90) {
           console.log
("You entered an Uppercase Letter.");
  } else if (charCode >= 97 && charCode <= 122) {
           console.log
("You entered a Lowercase Letter.");
  } else {
       console.log("You entered a special character or something else.");
  }
}


// Q#2 

var num1 = parseInt(prompt("Enter the first integer:"));
var num2 = parseInt(prompt("Enter the second integer:"));

if (isNaN(num1) || isNaN(num2)) {
  console.log("Please enter valid integers.");
} else {
  if (num1 > num2) {
    console.log(num1 + " is larger than " + num2);
  } else if (num2 > num1) {
    console.log(num2 + " is larger than " + num1);
  } else {
    console.log("Both numbers are equal.");
  }
}



// Q#3 
var number = parseFloat(prompt("Enter a number:"));

if (isNaN(number)) {
  console.log("Please enter a valid number.");
} else {
  if (number > 0) {
    console.log("The number is positive.");
  } else if (number < 0) {
    console.log("The number is negative.");
  } else {
    console.log("The number is zero.");
  }
}


// Q#4 
var char = prompt("Enter a single character: ");

if (char.length !== 1) {
    console.log("Please entry only one character.");
} else {
    var vowels = ['a', 'e', 'i', 'o', 'u'];
    var isVowel = vowels.includes(char.toLowerCase());
    console.log("Is vowel? " + isVowel);
    
}



// Q#5 
var correctPassword = "Secret123";  // Stored password
var userPassword = prompt("Enter your password:");

if (!userPassword) {
  console.log("Please enter your password.");
} else if (userPassword === correctPassword) {
  console.log("Correct! The password you entered matches the original password.");
} else {
  console.log("Incorrect password.");
}



// Q#6 

// Correct 
var greeting;
var hour = 13;
if (hour < 18) {
    greeting = "Good day";
}else{
    greeting = "Good evening";
}

console.log(greeting); // Output: Good day


// Q#7 


var time = prompt("Enter time in 24-hour format (e.g. 1900 for 7 PM):");

if (time === null || time.trim() === "") {
  console.log("Please enter the time!");
} else {
  time = parseInt(time);

  if (time >= 0 && time < 1200) {
    console.log("Good morning!");
  } else if (time >= 1200 && time < 1700) {
    console.log("Good afternoon!");
  } else if (time >= 1700 && time < 2100) {
    console.log("Good evening!");
  } else if (time >= 2100 && time <= 2359) {
    console.log("Good night!");
  } else {
    console.log("Invalid time. Please enter a time between 0000 and 2359.");
  }
}

// Chapter #13-15
// ARRAYS
//Q#1:  Declare an empty array using JS literal notation to store
// student names in future.


var studentName = []; // empty array
studentName.push("Khan <br>"); // add name
document.write(studentName); // Output: ["Khan"]

document.write("*********************************** <br>");



// Q#2
// Declare an empty array using JS object notation to store
// student names in future.

//  JS object notation
var studentNames = {
  names: []
};
studentNames.names.push("Ali");
studentNames.names.push("Ayesha");

document.write(studentNames.names);
// Output: { names: [ 'Ali', 'Ayesha' ] }


document.write("<br>***********************************<br>");


//Q#3
// Declare and initialize a strings array.
var fruits = ["Apple", "Orange", "Mango", "Peach"]


// Q#4
// Declare and initialize a numbers array.
var numbers = [1, 2, 3, 4, 5]

// Q#5
// Declare and initialize a boolean array.
var bool = [true, false]

// Q#6
// Declare and initialize a mixed array.
var mixedArr = ["Ali", 1,2,3, true, null]


// document.write("***************************************");


// Q#7
// Declare and Initialize an array and store available
// education qualifications in Pakistan (e.g. SSC, HSC, BCS,
// BS, BCOM, MS, M. Phil., PhD). Show the listed
// qualifications in your browser like:

// Declare and initialize the array
var arr = ["SSC", "HSC", "BSC", "BS", "BCOM", "MS", "M. PHIL.", "PhD"]  

// Display title
document.write("<h2>Qualifications in Pakistan:</h2>");

  // Display the list
document.write("<ol>"); // ordered list


for (var i = 0; i < arr.length; i++){
    document.write("<li>" + arr[i] + "</li>");
    
}

document.write("</ol>");



document.write("************************************* <br>")
// Q#8
// Write a program to store 3 student names in an array.Take
// another array to store score of these three students.
// Assume that total marks are 500 for each student, display
// the scores & percentages of students like:

  // Step 1: Store student names
var students = ["Akhlaque", "Asad", "Khan"];


  // Step 2: Store student scores
var studentsScore = [450, 400, 350];

// Total marks for each student
var totalScore = 500; 

// Step 3: Display the result
document.write("<h2>Student Scores and Percentages</h2>");

for (var i = 0; i < students.length; i++){
    var percentage = (studentsScore[i]/ totalScore) * 100;
    document.write(
        "Score of <strong> "+ students[i] + "</strong> is " + 
        studentsScore[i] + ". Percentage: " + percentage.toFixed(2) + "%<br>"  
    );
}

document.write("******************************************** <br>");


// // Q#9
// Initialize an array with color names. Display the array
// elements in your browser.
// a. Ask the user what color he/she wants to add to the
// beginning & add that color to the beginning of the array.
// Display the updated array in your browser.
// b. Ask the user what color he/she wants to add to the end
// & add that color to the end of the array. Display the
// updated array in your browser.
// c. Add two more color to the beginning of the array.
// Display the updated array in your browser.
// d. Delete the first color in the array. Display the updated
// array in your browser.
// e. Delete the last color in the array. Display the updated
// array in your browser.
// f. Ask the user at which index he/she wants to add a color
// & color name. Then add the color to desired
// position/index. . Display the updated array in your
// browser.
// g. Ask the user at which index he/she wants to delete
// color(s) & how many colors he/she wants to delete. Then
// remove the same number of color(s) from user-defined
// position/index. . Display the updated array in your
// browser.

var colorNames = ["Red", "Yellow", "Pink", "Brown"]
document.write("Original Array: ",colorNames);

document.write("<br>****************************************************** <br>");

// a: part
var userInput = prompt("Enter your color to add in beginning of array: ")
colorNames.unshift(userInput)
document.write("After ading color in beginning of array: ",colorNames);


document.write("<br>********************************************************* <br>");

// b: part
document.write("Now, Original Array:",colorNames);
var userInput = prompt("Enter your color to add in ending of array: ")
colorNames.push(userInput)
document.write("<br>After ading color in ending of array: ",colorNames);


document.write("<br>*********************************************************<br>");


// c: part
document.write("Orginial Array: ", colorNames)

colorNames.unshift("lightBlue", "lightGreen")
document.write("<br>After adding two colors in array: ", colorNames);

document.write("<br> ********************************************************* <br>");


// d: part
document.write("Original Array: ", colorNames);
colorNames.shift()
document.write("<br>After removing first element from array: ", colorNames);

document.write("<br>******************************************************** <br>");


// e: part
document.write("Original Array: " + colorNames);
colorNames.pop()
document.write("<br>After reoming last item from array: ", colorNames);

document.write("<br>******************************************************** <br>");

// f: part
document.write("<h3>Original Colors:</h3>");
document.write(colorNames.join(", "));

// ===== (f) Add color at user-defined index =====
var addIndex = +prompt("At which index do you want to add a color? (0 to " + colorNames.length + ")");
var newColor = prompt("Enter the name of the color you want to add:");
colorNames.splice(addIndex, 0, newColor); // insert at index

document.write("<h3>After Adding '" + newColor + "' at index " + addIndex + ":</h3>");
document.write(colorNames.join(", ") );

document.write("<br>******************************************************");

document.write("<h3>Original Colors:</h3>");
document.write(colorNames.join(", "));
// === (g) Delete color(s) from user-defined index ===
var delIndex = +prompt("At which index do you want to delete color(s)?");
var delCount = +prompt("How many colors do you want to delete?");

// Remove colors using splice
colorNames.splice(delIndex, delCount);

// Show updated array after deletion
document.write("<h2>After Deleting " + delCount + " Color(s) from Index " + delIndex + ":</h2>");
document.write(colorNames.join(", "));


document.write("<br>******************************************************");




// Q#10
// Write a program to store student scores in an array &
// sort the array in ascending order using Array’s sort
// method.
var studentScores = [300, 400, 250, 160]
document.write("Scores of Students before using sort method : ", studentScores, " <br>");

studentScores.sort()
document.write("Ordered Scores of Students, using sort method : ", studentScores) 


document.write("<br>******************************************************");


// Q#11
// Write a program to initialize an array with city names.
// Copy 3 array elements from cities array to selectedCities
// array.
// Step 1: Initialize the cities array
var cities = ["Karachi", "Hyderabad", "Larkana", "Sukkur", "Dadu", "Lahore"]
// Step 2: Display all cities
document.write("<br> <h2>Cities list: </h2>" + " <h3>"+ cities.join(", ") + "</h3>")


// Step 3: Copy 3 cities to selectedCities array (from index 2 to 4)
var selectedCities = cities.slice(2, 5) // Larkana, Sukkur, Dadu
// Step 4: Display selected cities
document.write("<h2>Selected Cities:</h2>" + "<h3>"+ selectedCities.join(", ") + "<\h2>");


document.write("<br>******************************************************<br>");
// Q#12
// Write a program to create a single string from the
// below mentioned array:
// var arr = [“This ”, “ is ”, “ my ”, “ cat”];
// (Use array’s join method)

// Step 1: Create the array
var arr = ["This", " is", " my", " cat"];
document.write("Array: <br>" + arr + "<br> <br>");

// Step 2: Join the array elements into a single string
var sentence = arr.join("");
// Step 3: Display the result in browser
document.write("<b>String: </b> <br>" + "<b>" + sentence + "</b>") ;


document.write("<br>******************************************************<br>");
// Q#13
// Create a new array. Store values one by one in such a way
// that you can access the values in the order in which they
// were stored. (FIFO-First In First Out)
// Step 1: Create an empty array
var newArray = [];

// Step 2: Add items (in newArray)
newArray.push("Keyboard");
newArray.push("Mouse");
newArray.push("Printer");
newArray.push("Monitor");


// Other way
// while(newArray.length > 0){
//   document.write("<b>Out: </b><br><b>" + newArray.shift() + "</b><br>");
// }


// Step 3: Show original queue
document.write("<b>Devices :</b> <br>" + newArray.join(", ") + "<br>");

// Step 4: Remove items in FIFO order (dequeue)
document.write("<b><br>Items removed in FIFO order:  <br></b>");
document.write("<b>Out: </b><br> <b>",newArray.shift() + "</b><br>");
document.write("<b>Out: </b><br> <b>",newArray.shift() + "</b><br>");
document.write("<b>Out: </b><br> <b>",newArray.shift() + "</b><br>");
document.write("<b>Out: </b><br> <b>",newArray.shift() + "</b><br>");


document.write("<br>******************************************************<br>");



// Q#14
// Create a new array. Store values one by one in such a way

// that you can access the values in reverse order. (Last In-
// First Out)

// Step 1: Create an empty array
var newArray = [];

// Step 2: Add items (LIFO behavior using push)
newArray.push("Keyboard");
newArray.push("Mouse");
newArray.push("Printer");
newArray.push("Monitor");

// Step 3: Show original stack
document.write("<b>Devices :</b> <br>" + newArray.join(", ") + "<br>");

// Step 4: Remove items in LIFO order (stack-style pop)
document.write("<b><br>Items removed in LIFO order:  <br></b>");
document.write("<b>Out: </b><br> <b>" + newArray.pop() + "</b><br>");
document.write("<b>Out: </b><br> <b>" + newArray.pop() + "</b><br>");
document.write("<b>Out: </b><br> <b>" + newArray.pop() + "</b><br>");
document.write("<b>Out: </b><br> <b>" + newArray.pop() + "</b><br>");


document.write("<br>******************************************************<br>");


// // Q#15
// Write a program to store phone manufacturers (Apple,
// Samsung, Motorola, Nokia, Sony & Haier) in an array.
// Display the following dropdown/select menu in your
// browser using document.write() method:

// Step 1: Create an array of mobile manufacturers
var manufacturers = ["Apple", "Samsung", "Motorola", "Nokia", "Sony", "Haier"]
// Step 2: Start the <select> element
document.write("<label for='manufacturers'>Choose a manufacturer:</label><br>");
document.write("<select id='manufacturers'>");

// Step 3: Use a loop to add <option> tags
for (var i = 0; i < manufacturers.length; i++){
    document.write("<option value='" + manufacturers[i] + "'>" + manufacturers[i] + "</option>");
}
// Step 4: Close the <select> element
document.write("</select>");



document.write("<br>******************************************************<br>");


// Chapter: 17-20:
// Q#1
// Declare and initialize an empty multidimensional array.
// (Array of arrays)
var multidimensional = [[], []]

// document.write("<br>****************************************************<br>");z

// Q#2
// Declare and initialize a multidimensional array
// representing the following matrix:
var multidimensionalArray = 
[
    [0, 1, 2, 3], 
    [1, 0, 1, 2],
    [2, 1, 0, 1]
]


for (var i = 0; i < multidimensionalArray.length; i++) {
    document.write(multidimensionalArray[i].join(" ") + "<br>");
}

document.write("<br>****************************************************<br>");

// Q#3
//Write a program to print numeric counting from 1 to 10.
document.write("1 to 10 numbers: <br> ")
for (var i = 1; i <= 10; i++ ){
    document.write(i + "<br>");
    
}


document.write("<br>****************************************************<br>");
// Q#4
// Write a program to print multiplication table of any
// number using for loop. Table number & length should be
// taken as an input from user.
var num = +prompt("Enter a number to see its multiplication: ")
var len = +prompt("Enter length of table: ")
document.write("<strong>The table of " + num +" and its length is "+ len + " : </strong> <br>" )
for (var i = 1; i <= len; i++){
    document.write(num + " x " + i + " = "  + (i * num) + "</br>")
}


document.write("<br>****************************************************<br>");


// Q#5
// Write a program to print items of the following array
// using for loop:
fruits = ["apple", "banana", "mango", "orange", "strawberry"];
document.write("<Strong>Array: </Strong> <br>")
for (var i = 0; i < fruits.length; i++){
    document.write(fruits[i], "<br>");    
}
document.write("<br><strong>Elements with index:</strong><br>");
for (var i = 0; i < fruits.length; i++) {
    document.write("Element at index " + i + " is " + fruits[i] + "<br>");
}






document.write("<br>****************************************************<br>");

// Q#6
// 6. Generate the following series in your browser. See
// example output.
// a. Counting: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15
// b. Reverse counting: 10, 9, 8, 7, 6, 5, 4, 3, 2, 1
// c. Even: 0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20
// d. Odd: 1, 3, 5, 7, 9, 11, 13, 15, 17, 19
// e. Series: 2k, 4k, 6k, 8k, 10k, 12k, 14k, 16k, 18k, 20k

// a: part 
document.write("<h2>Counting: </h2>")
for (var i = 1; i <= 15; i++){
    document.write(i, ", ")
}

document.write("<h2>Reverse counting:</h2>");
for (var i = 10; i >= 1; i--) {
    document.write(i + ", ");
}

document.write("<h2>Even:</h2>");
for (var i = 0; i <= 20; i++){
    if (i % 2 == 0)
    document.write(i + ", ");
}

document.write("<h2>Odd:</h2>");
for (var i = 0; i <= 20; i++){
    if (i % 2 != 0)
    document.write(i + ", ");
}

document.write("<h2>Series:</h2>");
for (var i = 1; i <= 20; i++){
    if (i % 2 == 0)
    document.write(i + "k, ");
}


document.write("<br>****************************************************<br>");

// Q#7
// You have an array
// A = [“cake”, “apple pie”, “cookie”, “chips”, “patties”]
// Write a program to enable “search by user input” in an
// array.
// After searching, prompt the user whether the given item is
// found in the list or not. Example:

// var A = ["cake", "apple pie", "cookie", "chips", "patties"]
// var userprompt = prompt("Welcome to ABC Bakery. What do you want to order sir/Ma'am?")

// for (var i = 0; i < A.length; i++){
//     if (A[i] === userprompt){
//         document.write(userprompt + " is <strong>available</strong> at index" + i + "in our bakery")
//         break
//     }
// }
// if ( i === A.length){
//     document.write("We are sorry." + userprompt+ "is <strong> not available</strong> in our bakery.");
        
// }


// an other way(best way)
var A = ["cake", "apple pie", "cookie", "chips", "patties"];
var userprompt = prompt("Welcome to ABC Bakery. What do you want to order sir/Ma'am?");
var found = false;

for (var i = 0; i < A.length; i++) {
    if (A[i].toLowerCase() === userprompt.toLowerCase()) {
        document.write(userprompt + " is <strong>available</strong> at index " + i + " in our bakery.");
        found = true;
        break;
    }
}

if (!found) {
    document.write("We are sorry. <strong>" + userprompt + "</strong> is <strong>not available</strong> in our bakery.");
}


document.write("<br>****************************************************<br>");

// Q#8
// Write a program to identify the largest number in the
// given array.
// A = [24, 53, 78, 91, 12].
var findLargestNum = [24, 53, 78, 91, 12];
var largest = findLargestNum[0];  // Assume first element is the largest initially

for (var i = 1; i < findLargestNum.length; i++){
    if (findLargestNum[i] > largest){
        largest = findLargestNum[i] // Update largest if current element is greater
    }
}
document.write("Array items: " + findLargestNum.join(", ") + "<br>");
document.write("The largest number is: " + largest);



document.write("<br>****************************************************<br>");

// Q#9
// Write a program to identify the smallest number in the
// given array.
// A = [24, 53, 78, 91, 12]

var findSmallestNum = [24, 53, 78, 91, 12];
var smallest = findSmallestNum[0];  // Assume first element is the smallest initially

for (var i = 1; i < findSmallestNum.length; i++){
    if (findSmallestNum[i] < smallest){
        smallest = findSmallestNum[i] // Update largest if current element is greater
    }
}
document.write("Array items: " + findSmallestNum.join(", ") + "<br>");
document.write("The largest number is: " + smallest);


document.write("<br>****************************************************<br>");

// Q#10
// Write a program to print multiples of 5 ranging 1 to
// 100.
document.write("<h3>Multiples of 5 from 1 to 100:</h3>");
for (var i =5; i <= 100; i += 5){
    document.write(i + ",")
}

//    20 chapter completed //